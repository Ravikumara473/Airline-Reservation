﻿Imports System.Data.SqlClient

Partial Class Flight_book
    Inherits System.Web.UI.Page


    Dim conn As New SqlConnection("Data Source=.;Initial Catalog=AirlineReservation11;Integrated Security=True")

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Dim strselectquery As String
        strselectquery = "select * from Flight_detail where Flight='" & DropDownList1.SelectedValue & "' and Source='" & DropDownList2.SelectedValue & "' and Destination='" & DropDownList3.SelectedValue & "'"
        conn.Open()
        Dim cmd As New SqlCommand(strselectquery, conn)
        Dim dr As SqlDataReader
        dr = cmd.ExecuteReader

        Label7.Visible = False
        If Not dr.HasRows Then
            Label7.Visible = True
            Exit Sub
        End If

        While dr.Read
            TextBox4.Text = dr.Item("Flight_no")
            TextBox3.Text = dr.Item("Flight_name")
            TextBox5.Text = dr.Item("Departure_time")
            TextBox6.Text = dr.Item("Arrival_time")
        End While
        conn.Close()



        strselectquery = "select * from Seats_avail where Source='" & DropDownList2.SelectedValue & "' and Destination='" & DropDownList3.SelectedValue & "' and Date='" & TextBox2.Text & "'"
        conn.Open()
        Dim cmd1 As New SqlCommand(strselectquery, conn)
        Dim dr1 As SqlDataReader
        dr1 = cmd1.ExecuteReader

        Dim no_seats As String
        If Not dr1.HasRows Then
            no_seats = "0"
        End If

        While dr1.Read
            no_seats = dr1.Item("Booked_seats")
        End While
        conn.Close()
        Label9.Text = no_seats
        Label11.Text = 50 - CInt(no_seats)
    End Sub

    Protected Sub Calendar1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Calendar1.SelectionChanged
        If Calendar1.SelectedDate < Now Then
            Exit Sub
        End If

        If Calendar1.SelectedDate > Now.AddDays(90) Then
            Exit Sub
        End If

        TextBox2.Text = Calendar1.SelectedDate.ToString("dd-MM-yy")
    End Sub

    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim strselectquery As String
        strselectquery = "select * from Seats_avail where Source='" & DropDownList2.SelectedValue & "' and Destination='" & DropDownList3.SelectedValue & "' and Date='" & TextBox2.Text & "'"
        conn.Open()
        Dim cmd As New SqlCommand(strselectquery, conn)
        Dim dr As SqlDataReader
        dr = cmd.ExecuteReader

        Dim no_seats, tot_seats As String

        While dr.Read
            tot_seats = dr.Item("Booked_seats")
        End While
        conn.Close()

        Label22.Visible = False
        If tot_seats <> "" Then
            tot_seats = CInt(tot_seats) + CInt(DropDownList5.SelectedValue) + CInt(DropDownList6.SelectedValue)
            If CInt(tot_seats) > 50 Then
                Label19.Visible = True
                Exit Sub
            Else
                Session("status") = "update"
            End If
        Else
            tot_seats = CInt(DropDownList5.SelectedValue) + CInt(DropDownList6.SelectedValue)
            Session("status") = "insert"
        End If

        no_seats = CInt(DropDownList5.SelectedValue) + CInt(DropDownList6.SelectedValue)

        Session("src") = DropDownList2.SelectedValue
        Session("dest") = DropDownList3.SelectedValue
        Session("dt") = TextBox2.Text
        Session("tot_seats") = tot_seats
        Session("no_seats") = no_seats

        Dim strqueryinsert As String
        strqueryinsert = "insert into Flight_book values('" & Session("Userid") & "','" & DropDownList1.SelectedValue & "','" & DropDownList2.SelectedValue & "','" & DropDownList3.SelectedValue & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & DropDownList4.SelectedValue & "','" & DropDownList5.SelectedValue & "','" & DropDownList6.SelectedValue & "','" & TextBox7.Text & "'," & Label21.Text & ")"
        Dim cmd1 As New SqlCommand(strqueryinsert, conn)
        conn.Open()
        cmd1.ExecuteNonQuery()
        conn.Close()
        Response.Redirect("Payment.aspx?PNR_number=" & TextBox7.Text & "&Total=" & Label21.Text)

    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim price As Integer
        Dim strselectquery As String
        strselectquery = "select * from Price_details where Flight='" & DropDownList1.SelectedValue & "' and Source='" & DropDownList2.SelectedValue & "' and Destination='" & DropDownList3.SelectedValue & "' and Class='" & DropDownList4.SelectedValue & "'"
        conn.Open()
        Dim cmd1 As New SqlCommand(strselectquery, conn)
        Dim dr As SqlDataReader
        dr = cmd1.ExecuteReader

        While dr.Read
            price = dr.Item("Price")
        End While
        conn.Close()

        Label21.Text = price * (CInt(DropDownList5.SelectedValue) + CInt(DropDownList6.SelectedValue))

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("userid") = "" Then
            Response.Redirect("User_login.aspx")
        End If
        TextBox1.Text = Session("userid")

        If IsPostBack Then
            Exit Sub
        End If

        TextBox7.Text = "KF" & Now.Year & Now.Month & Now.Day & Now.Hour & Now.Minute & Now.Second & Now.Millisecond
    End Sub

    Protected Sub TextBox7_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox7.TextChanged

    End Sub

    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Response.Redirect("Home.aspx")
    End Sub
End Class
