﻿
Partial Class Done
    Inherits System.Web.UI.Page

   
    Protected Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Response.Redirect("Genarate_tickets.aspx?PNR_number=" & Label2.Text & "&Total=" & Label3.Text)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label2.Text = Request.QueryString("PNR_number")
        Label3.Text = Request.QueryString("Total")
    End Sub
End Class
