﻿Imports System.Data.SqlClient

Partial Class Add_food
    Inherits System.Web.UI.Page
    Dim conn As New SqlConnection("Data Source=.;Initial Catalog=AirlineReservation11;Integrated Security=True")

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim strqueryinsert As String
        strqueryinsert = "insert into food_details values('" & TextBox1.Text & "','" & DropDownList1.SelectedValue & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & DropDownList2.SelectedValue & "')"

        conn.Open()
        Dim cmd As New SqlCommand(strqueryinsert, conn)
        cmd.ExecuteNonQuery()
        conn.Close()
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Then
            Label7.Visible = False
            Label8.Visible = True
        Else
            Label7.Visible = True
            Label8.Visible = False
        End If
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Response.Redirect("Admin_home.aspx")
    End Sub
End Class
