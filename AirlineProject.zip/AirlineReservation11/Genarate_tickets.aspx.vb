﻿Imports System.Data.SqlClient

Partial Class Default2
    Inherits System.Web.UI.Page
    Dim conn As New SqlConnection("Data Source=.;Initial Catalog=AirlineReservation11;Integrated Security=True")

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Redirect("Flight_book.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim pnr As String
        pnr = Request.QueryString("PNR_number")
        Dim strselectquery As String
        strselectquery = "select * from Flight_book where PNR_number='" & pnr & "'"
        conn.Open()
        Dim cmd As New SqlCommand(strselectquery, conn)
        Dim dr As SqlDataReader
        dr = cmd.ExecuteReader
        While dr.Read
            Label17.Text = dr.Item("PNR_number")
            Label30.Text = dr.Item("Flight")
            Label18.Text = dr.Item("Flight_no")
            Label33.Text = dr.Item("Flight_name")
            Label19.Text = dr.Item("source")
            Label34.Text = dr.Item("Destination")
            Label20.Text = dr.Item("Departure_date")
            Label35.Text = dr.Item("Departure_time")
            Label21.Text = dr.Item("Arrival_time")
            Label36.Text = dr.Item("Class")
            Label22.Text = dr.Item("Adults")
            Label37.Text = dr.Item("Children")
            Label32.Text = dr.Item("Total")
        End While
        conn.Close()
        Label23.Text = Session("seat_alloted")

        strselectquery = "select * from User_reg where User_name='" & Session("userid") & "'"
        conn.Open()
        Dim cmd1 As New SqlCommand(strselectquery, conn)
        Dim dr1 As SqlDataReader
        dr1 = cmd1.ExecuteReader
        While dr1.Read
            Label13.Text = dr1.Item("Name")
            Label14.Text = dr1.Item("Address")
            Label15.Text = dr1.Item("Phone_number")
            Label16.Text = dr1.Item("Email_id")


        End While
    End Sub

    Protected Sub LinkButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton2.Click
        Response.Redirect("Cancellation.aspx")
    End Sub

    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Response.Redirect("Home.aspx")
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Response.Redirect("Existers_tickets.aspx")
    End Sub

End Class
