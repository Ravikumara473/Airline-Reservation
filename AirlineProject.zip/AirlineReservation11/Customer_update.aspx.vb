﻿Imports System.Data.SqlClient

Partial Class Customer_update
    Inherits System.Web.UI.Page
    Dim conn As New SqlConnection("Data Source=.;Initial Catalog=AirlineReservation11;Integrated Security=True")

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim str As String
        Dim res As Integer
        str = TextBox1.Text
        res = checkchar(str)
        Label15.Visible = False
        If res = 0 Then
            Label15.Visible = True
            Exit Sub
        End If

        Dim strqueryinsert As String
        strqueryinsert = "update User_reg set User_name='" & TextBox6.Text & "',Name='" & TextBox1.Text & "',Password='" & TextBox7.Text & "',Confirm_password='" & TextBox8.Text & "', Age='" & TextBox9.Text & "', Address='" & TextBox5.Text & "', Phone_number='" & TextBox3.Text & "', Email_id='" & TextBox4.Text & "',Gender='" & DropDownList1.SelectedItem.Value & "' where User_name='" & TextBox6.Text & "'"
        Dim cmd1 As New SqlCommand(strqueryinsert, conn)
        conn.Open()
        cmd1.ExecuteNonQuery()
        conn.Close()

        Dim strselectquery As String
        strselectquery = "select * from User_reg where User_name='" & TextBox6.Text & "'"

        Dim cmd As New SqlCommand(strselectquery, conn)
        Dim da As New SqlDataAdapter(cmd)
        Dim ds As New Data.DataSet
        da.Fill(ds)
        GridView1.DataSource = ds.Tables(0)
        GridView1.DataBind()


        Button3.Visible = True
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If IsPostBack Then
            Exit Sub
        End If

        Dim username As String
        username = Request.QueryString("un")
        TextBox6.Text = username
        TextBox6.Enabled = False

        Dim strselectquery As String
        strselectquery = "select * from User_reg where User_name='" & TextBox6.Text & "'"
        conn.Open()
        Dim cmd As New SqlCommand(strselectquery, conn)
        Dim dr As SqlDataReader
        dr = cmd.ExecuteReader

        While dr.Read
            TextBox7.Text = dr.Item("Password")
            TextBox8.Text = dr.Item("Confirm_password")
            TextBox1.Text = dr.Item("Name")
            TextBox9.Text = dr.Item("Age")
            TextBox5.Text = dr.Item("Address")
            TextBox3.Text = dr.Item("Phone_number")
            TextBox4.Text = dr.Item("Email_id")
            DropDownList1.SelectedItem.Value = dr("Gender")


        End While
        conn.Close()
    End Sub

    Public Function checkchar(ByVal str As String) As Integer
        Dim i As Integer
        Dim flag As Integer
        flag = 1
        For i = 0 To str.Length - 1
            If IsNumeric(str(i)) Then
                flag = 0
            End If
        Next
        Return flag
    End Function

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Redirect("User_reg.aspx")
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Response.Redirect("User_login.aspx")
    End Sub


    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Response.Redirect("User_reg.aspx")
    End Sub
End Class
