﻿Imports System.Data.SqlClient

Partial Class Default2
    Inherits System.Web.UI.Page

    Dim conn As New SqlConnection("Data Source=.;Initial Catalog=AirlineReservation11;Integrated Security=True")


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label8.Text = Request.QueryString("PNR_number")
        Label9.Text = Request.QueryString("Total")
        

    End Sub



    Function check_seat(ByVal seat As Integer) As Integer

        Dim strselectquery As String
        strselectquery = "select * from Seats_reserve where Source='" & Session("src") & "' and Destination='" & Session("dest") & "' and Date='" & Session("dt") & "' and Seat_no=" & seat
        conn.Open()
        Dim cmd1 As New SqlCommand(strselectquery, conn)
        Dim dr1 As SqlDataReader
        dr1 = cmd1.ExecuteReader

        If Not dr1.HasRows Then
            conn.Close()
            Return 1
        End If
        conn.Close()

        Return 0
    End Function


    Function insert_seat(ByVal seat As Integer) As Integer
        Dim strqueryinsert As String
        strqueryinsert = "insert into Seats_reserve values('" & Label8.Text & "','" & Session("src") & "','" & Session("dest") & "','" & Session("dt") & "'," & seat & ")"

        conn.Open()
        Dim cmd As New SqlCommand(strqueryinsert, conn)
        cmd.ExecuteNonQuery()
        conn.Close()

        Return 1
    End Function

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim src, dest, dt, tot_seats, no_of_seats, status As String

        src = Session("src")
        dest = Session("dest")
        dt = Session("dt")
        no_of_seats = Session("no_seats")
        status = Session("status")
        tot_seats = Session("tot_seats")

        Dim strquerystatus As String

        If status = "insert" Then
            strquerystatus = "insert into Seats_avail values('" & src & "','" & dest & "','" & dt & "'," & tot_seats & ")"
        ElseIf status = "update" Then
            strquerystatus = "update Seats_avail set Booked_seats=" & tot_seats & " where Source='" & src & "' and Destination='" & dest & "' and Date='" & dt & "'"
        End If

        conn.Open()
        Dim cmd2 As New SqlCommand(strquerystatus, conn)
        cmd2.ExecuteNonQuery()
        conn.Close()


        Dim strqueryinsert As String
        strqueryinsert = " insert into Payment values('" & Label8.Text & "','" & DropDownList1.SelectedValue & "','" & DropDownList2.SelectedValue & "','" & TextBox1.Text & "','" & TextBox2.Text & "','" & Label9.Text & "')"
        conn.Open()
        Dim cmd As New SqlCommand(strqueryinsert, conn)
        cmd.ExecuteNonQuery()
        conn.Close()

        Dim seat_avail, cnt As Integer
        cnt = 0

        Dim strseat As String
        strseat = ""

        For i = 1 To 50
            seat_avail = check_seat(i)
            If seat_avail Then
                strseat = strseat & " " & i
                insert_seat(i)
                cnt = cnt + 1
                If cnt = CInt(no_of_seats) Then
                    Exit For
                End If
            End If
        Next

        Session("seat_alloted") = strseat

        Image1.Visible = True
        LinkButton1.Visible = True
        Response.Redirect("otp.aspx?PNR_number=" & Label8.Text & "&Total=" & Label9.Text)



    End Sub

    

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Response.Redirect("Flight_book.aspx")
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Redirect("Home.aspx")
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Redirect("Genarate_tickets.aspx?PNR_number=" & Label8.Text & "&Total=" & Label9.Text)
    End Sub

    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Response.Redirect("Home.aspx")
    End Sub

    
End Class
