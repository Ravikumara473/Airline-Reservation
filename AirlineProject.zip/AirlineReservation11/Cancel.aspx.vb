﻿
Partial Class Cancel
    Inherits System.Web.UI.Page

    Protected Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Response.Redirect("Cancellation.aspx")
    End Sub
End Class
