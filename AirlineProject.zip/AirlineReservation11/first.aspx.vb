﻿
Partial Class first
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If My.Computer.Network.IsAvailable Then
            Response.Redirect("welcome.aspx")
        Else
            Label1.visible = True
        End If
    End Sub
End Class
