﻿Imports System.Data.SqlClient

Partial Class User_reg
    Inherits System.Web.UI.Page
    Dim conn As New SqlConnection("Data Source=.;Initial Catalog=AirlineReservation11;Integrated Security=True")

    Public Function checkchar(ByVal str As String) As Integer
        Dim i As Integer
        Dim flag As Integer
        flag = 1
        For i = 0 To str.Length - 1
            If IsNumeric(str(i)) Then
                flag = 0
            End If
        Next
        Return flag
    End Function

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox9.Text = "" Or DropDownList1.SelectedItem.Value = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox6.Text = "" Or TextBox7.Text = "" Or TextBox8.Text = "" Then
            Label10.Visible = True
            Exit Sub
        End If

        Dim str As String
        Dim res As Integer
        str = TextBox1.Text
        res = checkchar(str)
        Label15.Visible = False
        If res = 0 Then
            Label15.Visible = True
            TextBox1.Text = ""

            Exit Sub
        End If

        Dim strselectquery As String
        strselectquery = "select * from User_reg where User_name='" & TextBox6.Text & "'"
        conn.Open()
        Dim cmd As New SqlCommand(strselectquery, conn)
        Dim dr As SqlDataReader
        dr = cmd.ExecuteReader
        Label14.Visible = False
        If dr.HasRows Then
            Label14.Visible = True
            Exit Sub
        End If
        conn.Close()

        Dim strqueryinsert As String
        strqueryinsert = "insert into User_reg values('" & TextBox1.Text & "','" & TextBox9.Text & "','" & DropDownList1.SelectedItem.Value & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "')"
        Dim cmd1 As New SqlCommand(strqueryinsert, conn)
        conn.Open()
        cmd1.ExecuteNonQuery()
        conn.Close()




        strselectquery = "select * from User_reg where User_name='" & TextBox6.Text & "'"
        Dim cmd2 As New SqlCommand(strselectquery, conn)
        Dim da As New SqlDataAdapter(cmd2)
        Dim ds As New Data.DataSet
        da.Fill(ds)
        GridView1.DataSource = ds.Tables(0)
        GridView1.DataBind()


        Button3.Visible = True
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Redirect("Customer_update.aspx?un=" & TextBox6.Text)
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Response.Redirect("User_login.aspx")
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Response.Redirect("Welcome.aspx")
    End Sub
End Class
