﻿Imports System.Data.SqlClient

Partial Class Default2
    Inherits System.Web.UI.Page
    Dim conn As New SqlConnection("Data Source=.;Initial Catalog=AirlineReservation11;Integrated Security=True")

   


    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Response.Redirect("Home.aspx")
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Redirect("Home.aspx")
    End Sub

    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Response.Redirect("Home.aspx")
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim strselectquery As String
        strselectquery = "select * from Flight_book where PNR_number='" & TextBox1.Text & "'"
        conn.Open()
        Dim cmd As New SqlCommand(strselectquery, conn)
        Dim dr As SqlDataReader
        dr = cmd.ExecuteReader

        If dr.HasRows Then
            Response.Redirect("Genarate_tickets.aspx?PNR_number=" & TextBox1.Text)
        End If

        Label3.Visible = True
        conn.Close()
    End Sub
End Class
