﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Specialized;



public partial class otp : System.Web.UI.Page
{
   
   protected void Button1_Click1(object sender, EventArgs e)
    {
        Panel3.Visible = false;
        Panel4.Visible = true;
        Random random = new Random();
        int value = random.Next(1001, 9999);
        string destinationaddr = "91" + TextBox3.Text;
        string message = "Your OTP Number is " + value + " ( Sent By : R2A )";
        //Label3.Text = message;
        String message1 = HttpUtility.UrlEncode(message);

        using (var wb = new WebClient())
        {
            byte[] response = wb.UploadValues("https://api.textlocal.in/send/", new NameValueCollection()
                {
                {"apikey" , "L3pNIgwbLi8-gXFH6yvwE7M2Yd9aopkit0cvfXDveM"},
                {"numbers" , destinationaddr},
                {"message" , message1},
                {"sender" , "TXTLCL"}
                });
            string result = System.Text.Encoding.UTF8.GetString(response);
            Session["otp"] = value;


        }
    }


   protected void Button2_Click(object sender, EventArgs e)
   {
       if (TextBox4.Text == Session["otp"].ToString())
       {
           Panel4.Visible = false;
           Label3.Text = "Your Mobile Number Has Been Verified Successfully - Thanks";
           Button3.Visible = true;
           
       }
       else
       {
           Label3.Text = "OTP Number is Not Correct : Your Mobile Number not Verified";
           Panel4.Visible = true;

       }
   }



   protected void Page_Load(object sender, EventArgs e)
   {
     
       {
          
           Label7.Text = Request.QueryString["PNR_number"];
           Label8.Text = Request.QueryString["Total"];
       }
       
   }
   protected void Button3_Click(object sender, EventArgs e)
   {
       Response.Redirect("Done.aspx?PNR_number="+Label7.Text+"&Total="+Label8.Text);
   }
}


