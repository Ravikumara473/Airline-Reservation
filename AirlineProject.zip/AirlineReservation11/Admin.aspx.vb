﻿Imports System.Data.SqlClient

Partial Class Admin
    Inherits System.Web.UI.Page
    Dim conn As New SqlConnection("Data Source=.;Initial Catalog=AirlineReservation11;Integrated Security=True")

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim strselectquery As String
        strselectquery = "select * from Price_details where Destination='" & DropDownList1.SelectedValue & "' and Class='" & DropDownList2.SelectedValue & "'"
        conn.Open()
        Dim cmd As New SqlCommand(strselectquery, conn)
        Dim dr As SqlDataReader
        dr = cmd.ExecuteReader

        While dr.Read
            TextBox2.Text = dr.Item("Price")
        End While
        conn.Close()
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim strqueryinsert As String
        strqueryinsert = " update Price_details set Price='" & TextBox1.Text & "' where Destination='" & DropDownList1.SelectedValue & "' and Class='" & DropDownList2.SelectedValue & "'"
        Dim cmd As New SqlCommand(strqueryinsert, conn)
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()

        Dim strselectquery As String
        strselectquery = "select * from Price_details"
        Dim cmd1 As New SqlCommand(strselectquery, conn)
        Dim da As New SqlDataAdapter(cmd1)
        Dim ds As New Data.DataSet
        da.Fill(ds)
        GridView1.DataSource = ds.Tables(0)
        GridView1.DataBind()
    End Sub

    Protected Sub LinkButton3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton3.Click
        Response.Redirect("Welcome.aspx")
    End Sub

    
    
    Protected Sub TextBox1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Protected Sub TextBox2_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged

    End Sub
End Class
