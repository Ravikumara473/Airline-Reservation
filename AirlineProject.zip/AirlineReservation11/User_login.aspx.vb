﻿Imports System.Data.SqlClient

Partial Class Default2
    Inherits System.Web.UI.Page
    Dim conn As New SqlConnection("Data Source=.;Initial Catalog=Airlinereservation11;Integrated Security=True")



    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim strselectquery As String
        strselectquery = "select * from User_reg where User_name='" & TextBox1.Text & "' and Password='" & TextBox2.Text & "'"
        conn.Open()
        Dim cmd As New SqlCommand(strselectquery, conn)
        Dim dr As SqlDataReader
        dr = cmd.ExecuteReader
        Label4.Visible = False
        If dr.HasRows Then
            Session("Userid") = TextBox1.Text
            Response.Redirect("Home.aspx")
        End If
        Label4.Visible = True
        conn.Close()
    End Sub

    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Response.Redirect("Welcome.aspx")
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        Label4.Visible = False
    End Sub
End Class
