﻿Imports System.Data.SqlClient

Partial Class Cancellation
    Inherits System.Web.UI.Page

    Dim conn As New SqlConnection("Data Source=.;Initial Catalog=AirlineReservation11;Integrated Security=True")

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim strselectquery As String
        strselectquery = "select * from Flight_book where PNR_number='" & TextBox1.Text & "'"
        Dim cmd As New SqlCommand(strselectquery, conn)
        Dim da As New SqlDataAdapter(cmd)
        Dim ds As New Data.DataSet
        da.Fill(ds)
        GridView1.DataSource = ds.Tables(0)
        GridView1.DataBind()

        Button3.Visible = True
    End Sub

   

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Redirect("Home.aspx")
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Response.Redirect("Genarate_tickets.aspx")
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim strqueryinsert As String
        strqueryinsert = "insert into Cancel_book select * from Flight_book where PNR_number='" & TextBox1.Text & "'"
        Dim cmd1 As New SqlCommand(strqueryinsert, conn)
        conn.Open()
        cmd1.ExecuteNonQuery()
        conn.Close()


        Dim strdeletequery As String
        strdeletequery = "delete from Flight_book where PNR_number='" & TextBox1.Text & "'"
        conn.Open()
        Dim cmd As New SqlCommand(strdeletequery, conn)
        Dim dr1 As SqlDataReader
        dr1 = cmd.ExecuteReader

        Image1.Visible = True
        Response.Redirect("Cancel.aspx")
    End Sub

    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Response.Redirect("Home.aspx")
    End Sub
End Class
