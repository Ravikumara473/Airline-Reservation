﻿Imports System.Data.SqlClient

Partial Class feedback
    Inherits System.Web.UI.Page
    Dim conn As New SqlConnection("Data Source=.;Initial Catalog=AirlineReservation11;Integrated Security=True")

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or DropDownList1.SelectedItem.Value = "" Or DropDownList2.SelectedItem.Value = "" Or TextBox2.Text = "" Or DropDownList3.SelectedItem.Value = "" Then
            Label7.Visible = False
            Exit Sub
        End If

        Dim StrQueryInsert As String
        StrQueryInsert = "Insert into feed_back values('" & TextBox1.Text & "','" & DropDownList1.SelectedItem.Value & "','" & DropDownList2.SelectedItem.Value & "','" & TextBox2.Text & "','" & DropDownList3.SelectedItem.Value & "')"

        Dim cmd As New SqlCommand(StrQueryInsert, conn)

        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()

        Label7.Visible = True

    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Response.Redirect("Contact_us.aspx")
    End Sub

    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Response.Redirect("Home.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("userid") = "" Then
            Response.Redirect("User_login.aspx")
        End If
        TextBox1.Text = Session("userid")

        If IsPostBack Then
            Exit Sub
        End If
    End Sub
End Class
