﻿Imports System.Data.SqlClient
Partial Class updatefood
    Inherits System.Web.UI.Page
    Dim conn As New SqlConnection("Data Source=.;Initial Catalog=AirlineReservation11;Integrated Security=True")
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim strdeletequery As String
        strdeletequery = "delete from food_details where Food_name='" & TextBox1.Text & "'"
        conn.Open()
        Dim cmd As New SqlCommand(strdeletequery, conn)
        Dim dr1 As SqlDataReader
        dr1 = cmd.ExecuteReader
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        LinkButton2.Visible = True
        LinkButton3.Visible = True
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub LinkButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton2.Click
        Dim strSelectQuery As String
        strSelectQuery = "select * from food_details where class_type='Business'"

        Dim cmd As New SqlCommand(strSelectQuery, conn)
        Dim da As New SqlDataAdapter(cmd)
        Dim ds As New Data.DataSet
        da.Fill(ds)
        GridView1.DataSource = ds.Tables(0)
        GridView1.DataBind()
    End Sub

    Protected Sub LinkButton3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton3.Click
        Dim strSelectQuery As String
        strSelectQuery = "select * from food_details where class_type='Economy'"

        Dim cmd As New SqlCommand(strSelectQuery, conn)
        Dim da As New SqlDataAdapter(cmd)
        Dim ds As New Data.DataSet
        da.Fill(ds)
        GridView1.DataSource = ds.Tables(0)
        GridView1.DataBind()
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Response.Redirect("Admin_home.aspx")
    End Sub
End Class
